"use strict";
var Student = (function () {
    function Student(rollNo, name, course, branch) {
        this.rollNo = rollNo;
        this.name = name;
        this.course = course;
        this.branch = branch;
    }
    return Student;
}());
exports.Student = Student;
//# sourceMappingURL=student.js.map