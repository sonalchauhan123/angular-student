export class Student {
  constructor(
    public rollNo: number,
    public name: string,
    public course: string,
    public branch?: string
  ) {  }
}
